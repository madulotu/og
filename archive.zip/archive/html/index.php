<pre> <?php echo microtime(true); 

echo "\n\n";

echo json_encode ($_SERVER); ?></pre>

<?php echo phpinfo ();

