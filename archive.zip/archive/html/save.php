<?php 

echo $_POST['text'];

file_put_contents ('text', $_POST['text']);



